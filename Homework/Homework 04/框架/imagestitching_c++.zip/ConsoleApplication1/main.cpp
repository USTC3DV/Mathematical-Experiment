#include<iostream>
#include<opencv2/opencv.hpp>
#include<opencv2/xfeatures2d.hpp>
#include<opencv2/stitching.hpp>
#include "ima.h"

using namespace std;
using namespace cv;
using namespace cv::xfeatures2d;

int main()
{

	Mat image_left = imread("D:/left.jpg");
	Mat image_right = imread("D:/right.jpg");
	if (image_left.empty() || image_right.empty())
	{
		cout << "No Image!" << endl;
		system("pause");
		return -1;
	}

	Mat WarpImg, DstImg;
	if (!Image_Stitching(image_left, image_right, WarpImg, DstImg, false))
	{
		cout << "can not stitching the image!" << endl;
		system("pause");
		return false;
	}


	if (!OpenCV_Stitching(image_left, image_right))
	{
		cout << "can not stitching the image!" << endl;
		system("pause");
		return false;
	}

	waitKey(0);
	destroyAllWindows();
	system("pause");
	return 0;
}
