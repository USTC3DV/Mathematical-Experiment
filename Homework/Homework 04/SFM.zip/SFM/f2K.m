function K = f2K(f)

K = eye(3);
K(1,1) = f;
K(2,2) = f;