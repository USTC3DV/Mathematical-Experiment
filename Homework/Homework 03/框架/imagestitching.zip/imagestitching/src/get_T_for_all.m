function [ T_out ] = get_T_for_all(Ts, row, rlt, Matt)
%%TODO: compute transform matrix (with respect to the central image we just found) for every image

end

