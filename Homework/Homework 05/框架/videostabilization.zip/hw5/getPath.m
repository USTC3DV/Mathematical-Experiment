function path = getPath(MeshSize, tracks)
%GETPATH Compute the bundled camera path
%   track is the set of trajectories of the input video, backList indicate
%   the background trajectories.     
    nFrames = tracks.nFrame;
    if nFrames < 2
        error('Wrong inputs') ;
    end
    path = zeros(nFrames, MeshSize, MeshSize, 3, 3);
    for row = 1:MeshSize
        for col = 1:MeshSize
            path(1, row, col, :, :) = eye(3);
        end
    end
    fprintf('%5d', 1);
    for frameIndex = 2:nFrames
        fprintf('%5d', frameIndex);
        if mod(frameIndex, 20) == 0
            fprintf('\n') ;
        end                
        %TODO：按照论文中的方法，得到path的值，需要用到NewWarping函数和TrackLib.m中的getF函数           
    end
end

