% Compute As-similar-as-possible warping
%
% usage:
%
% [homos]=AsSimilarAsPossible(imageHeight, imageWidth, quadHeight, quadWidth, f1, f2, alpha);
% 
% Tan SU
% Feb, 2018
% tansu@astri.org