/********************************************************************************
** Form generated from reading UI file 'Poisson.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_POISSON_H
#define UI_POISSON_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PoissonClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *PoissonClass)
    {
        if (PoissonClass->objectName().isEmpty())
            PoissonClass->setObjectName(QString::fromUtf8("PoissonClass"));
        PoissonClass->resize(600, 400);
        menuBar = new QMenuBar(PoissonClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        PoissonClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(PoissonClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        PoissonClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(PoissonClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        PoissonClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(PoissonClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        PoissonClass->setStatusBar(statusBar);

        retranslateUi(PoissonClass);

        QMetaObject::connectSlotsByName(PoissonClass);
    } // setupUi

    void retranslateUi(QMainWindow *PoissonClass)
    {
        PoissonClass->setWindowTitle(QCoreApplication::translate("PoissonClass", "Poisson", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PoissonClass: public Ui_PoissonClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_POISSON_H
