#pragma once
#include <QWidget>
#include <opencv2/core/core.hpp>
#include "PoissonFusion.h"

class ChildWindow;
QT_BEGIN_NAMESPACE
class cv::Mat; //class QImage;
class QPainter;
QT_END_NAMESPACE

enum DrawStatus
{
	kChoosePolygon,
	kChooseFreehand,
	kPasteClone,
	kPasteSeamless, // kChoose, //kPaste,
	kNone
};

class ImageWidget :
	public QWidget
{
	Q_OBJECT

public:
	ImageWidget(ChildWindow* relatewindow);
	~ImageWidget(void);

	int ImageWidth();											// Width of image
	int ImageHeight();											// Height of image
	//void set_draw_status_to_choose();
	//void set_draw_status_to_paste();
	void set_draw_status(DrawStatus astatus);
	cv::Mat image();
	void set_source_window(ChildWindow* childwindow);
	void set_mixed(bool amixed);

protected:
	void paintEvent(QPaintEvent* paintevent);

	void mousePressEvent(QMouseEvent* mouseevent);
	void mousePressChoosePolygon(QMouseEvent* mouseevent);
	void mousePressChooseFreehand(QMouseEvent* mouseevent);
	void mousePressPasteClone(QMouseEvent* mouseevent);
	void mousePressPasteSeamless(QMouseEvent* mouseevent);

	void mouseMoveEvent(QMouseEvent* mouseevent);
	void mouseMoveChoosePolygon(QMouseEvent* mouseevent);
	void mouseMoveChooseFreehand(QMouseEvent* mouseevent);
	void mouseMovePasteClone(QMouseEvent* mouseevent);
	void mouseMovePasteSeamless(QMouseEvent* mouseevent);

	void mouseReleaseEvent(QMouseEvent* mouseevent);
	void mouseReleaseChoosePolygon(QMouseEvent* mouseevent);
	void mouseReleaseChooseFreehand(QMouseEvent* mouseevent);
	void mouseReleasePasteClone(QMouseEvent* mouseevent);
	void mouseReleasePasteSeamless(QMouseEvent* mouseevent);

	void DrawPasteClone();
	void DrawPasteSeamless();

public slots:
	// File IO
	void Open(QString filename);								// Open an image file, support ".bmp, .png, .jpg" format
	void Save();												// Save image to current file
	void SaveAs();												// Save image to another file

	// Image processing
	void Invert();												// Invert pixel value in image
	void Mirror(bool horizontal = false, bool vertical = true);		// Mirror image vertically or horizontally
	void TurnGray();											// Turn image to gray-scale map
	void Restore();												// Restore image to origin

	void CopytoClipboard();

	void BeginPasteClone();
	void BeginPasteSeamless();

public:
	QPoint						point_start_;					// Left top point of rectangle region
	QPoint						point_last;
	QPoint						point_end_;						// Right bottom point of rectangle region

private:
	//QImage* image_;						// image
	//QImage* image_backup_;
	cv::Mat						image_mat_active;
	cv::Mat						image_mat;						// image 
	cv::Mat						image_mat_backup;

	CPoissonFusion				poisson_editing;

	QPolygon					choosed_polygon;
	QPoint						paste_pos;

	// Pointer of child window
	ChildWindow* source_window_;				// Source child window

	// Signs
	DrawStatus					draw_status_;					// Enum type of draw status
	bool						is_choosing_;
	bool						is_choosing_polyedge;
	bool						is_pasting_;
	bool						is_pasting_holding;
};
