function imret = blendImagePoisson(im1, im2, roi, targetPosition)

% input: im1 (background), im2 (foreground), roi (in im2), targetPosition (in im1)
% im1:sea   im2:bear

[height1,width1,dim1]=size(im1);
[height2,width2,dim2]=size(im2);
[coorx2,coory2] = meshgrid(1:width2, 1:height2);
[coorx1,coory1] = meshgrid(1:width1, 1:height1);
coor2=[coorx2(:) coory2(:)];
coor1=[coorx1(:) coory1(:)];
rewi=height2*width2;

%% TODO: compute blended image
